#Page 10 Statements

CREATE DATABASE IF NOT EXISTS CAR_SALES;

USE CAR_SALES;

CREATE TABLE IF NOT EXISTS MANUFACTURER
( 
  MCODE INT AUTO_INCREMENT, 
  MNAME ENUM('Audi', 'BMW', 'Opel', 'Volkswagen', 'Peugeot', 'Renault', 'Alfa Romeo', 'Ford', 'Hyundai', 'Kia', 
           'Saab', 'SsangYong', 'Honda', 'Lexus', 'Mazda', 'Mitsubishi', 'Nissan', 'Suzuki', 'Toyota') NOT NULL,
  MCOUNTRY VARCHAR(20),
  PRIMARY KEY(MCODE)
);

CREATE TABLE IF NOT EXISTS CAR
( 
  REG VARCHAR(15), 
  MODEL VARCHAR(10) NOT NULL, 
  COST DOUBLE(8,2), 
  MCODE INT, 
  PRIMARY KEY(REG),
  CONSTRAINT FK_MCODE FOREIGN KEY(MCODE) 
  REFERENCES MANUFACTURER(MCODE) 
  ON UPDATE CASCADE ON DELETE SET NULL
);

ALTER TABLE car MODIFY COLUMN cost DECIMAL(8,2);

#Page 11 Statements

INSERT INTO MANUFACTURER (MNAME, MCOUNTRY) VALUES
 ('Audi','Germany'),
 ('BMW','Germany'), 
 ('Opel','Germany'),
 ('Volkswagen','Germany'),
 ('Peugeot','France'),
 ('Renault','France'),
 ('Alfa Romeo','Italy'),
 ('Ford','USA'),
 ('Hyundai','South Korea'),
 ('Kia','South Korea'),
 ('Saab','Swedan'),
 ('SsangYong','Swedan'),
 ('Honda','Japan'),
 ('Lexus','Japan'),
 ('Mazda','Japan'),
 ('Mitsubishi','Japan'),
 ('Nissan','Japan'),
 ('Suzuki','Japan'),
 ('Toyota', 'Japan');
 
 INSERT INTO CAR VALUES 
 ('141-KK-345','i30',20760, 9),
 ('11-WD-1876','i35',14500, 9),
 ('151-KK-100','Astra',24800, 3),
 ('12-WX-222','Corolla',19870, 19),
 ('142-WD-7811','Vectra',28900, 3),
 ('08-KK-1234','Polo',6500, 4),
 ('10-WX-9875','Golf',9500, 4);
 
 #Exercise
 #1
 CREATE TABLE IF NOT EXISTS CUSTOMER
( 
  customerId int auto_increment, 
  fName VARCHAR(15), 
  lName VARCHAR(15),  
  emailAddress VARCHAR(40), 
  PRIMARY KEY(customerId)
);
 
#2
CREATE TABLE IF NOT EXISTS VIEWINGS
( 
  customerId int, 
  reg VARCHAR(15), 
  viewingDate DATE,  
  comments VARCHAR(250), 
  PRIMARY KEY(customerId, reg),
  CONSTRAINT FK_CUST FOREIGN KEY(customerId) 
  REFERENCES CUSTOMER(customerId) 
  ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT FK_CAR FOREIGN KEY(reg) 
  REFERENCES CAR(reg) 
  ON UPDATE CASCADE ON DELETE CASCADE
);

#3
insert into customer(fName, lName, emailAddress)
values('Philip', 'Cody','pcody@gmail.com'),
('Sally', 'Dunne','sally.dunne"gmail.com');

insert into viewings values
(1, '141-KK-345', '2018-11-21', 'Not interested'),
(1, '151-KK-100', '2018-11-21', 'Definitely interested'),
(1, '142-WD-7811', '2018-11-21', 'Too expensive'),
(2, '141-KK-345', '2018-11-28', 'Loved it'),
(2, '10-WX-9875', '2018-11-28', 'Mileage too high');

#4
select model, viewingDate, comments
from car join viewings
on car.reg = viewings.reg;

select concat(fName, ' ', lName) as Name, model, viewingDate, comments
from car join viewings
on car.reg = viewings.reg
join customer 
on customer.customerId = viewings.customerId;