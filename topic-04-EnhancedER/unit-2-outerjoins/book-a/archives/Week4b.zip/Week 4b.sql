use library;

#Page 8 Exercise
select concat(fname, ' ', lname) as 'Author', ISBN as 'ISBN' from author left join authorship 
on author.authorId = authorship.authorId order by lname, fname;

#Page 10 Exercise
select  title, concat(fname,' ', lname) as Name from book join authorship on book.isbn = authorship.isbn 
right join author on author.authorid = authorship.authorid order by title, lname, fname;


#Movies Exercise
use movies;

insert into reviewer values(209, 'Liam Collins');

#1
select title as 'Film Title', name as 'Reviewer Name', stars as 'Number of Stars' from 
reviewer  join rating
on reviewer.rid = rating.rid
right join film on
film.fid = rating.fid;

#2
select name as 'Reviewer Name', title as 'Film Title', stars as 'Number of Stars' from 
film  join rating
on film.fid = rating.fid
right join reviewer on
reviewer.rid = rating.rid;