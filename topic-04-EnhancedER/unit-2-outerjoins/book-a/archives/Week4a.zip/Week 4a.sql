use library;

#Page 4 Exercises
select title as 'Books currently on loan' 
from book join bookCopy 
on book.ISBN = bookCopy.ISBN 
join loan 
on bookCopy.copyId = loan.copyId 
where dateback is null
order by book.title;

select title as 'Books currently on loan' , concat(fname, ' ', lname) as 'Student Name', dateOut, dateDue 
from book join bookCopy 
on book.ISBN = bookCopy.ISBN 
join loan on bookCopy.copyId = loan.copyId 
join student on loan.studentId = student.studentId 
where dateback is null
order by title;

select title as 'Book Title', concat(fname, ' ', lname) as 'Author' 
from author join authorship
on authorship.authorId = author.authorId 
join book on authorship.ISBN = book.ISBN
order by title, lname, fname;

select title as 'Book Title', concat(fname, ' ', lname) as 'Author' 
from author join authorship 
on authorship.authorId = author.authorId 
join book on authorship.ISBN = book.ISBN 
where title like '%Javascript%'
order by title, lname, fname;

select title, count(*) as 'Number of Loans' 
from book join bookCopy 
on book.ISBN = bookCopy.ISBN 
join loan 
on bookCopy.copyId = loan.copyId 
group by title;

#Movies Exercise
use movies;

#1
select name as 'Reviewer Name', title as 'Film title', stars as 'Number of Stars', ratingDate as 'Date of Rating'  from 
reviewer  join rating
on reviewer.rid = rating.rid
join  film on
film.fid = rating.fid;

#2
select title as 'Films Reviewed by Chris Jackson' from 
reviewer  join rating
on reviewer.rid = rating.rid
join  film on
film.fid = rating.fid
where name = 'Chris Jackson';