USE CAR_SALES;

#Page 9 Exercise
create user Management identified by 'boss';

grant all on CAR_SALES to management with grant option;

create user salesperson identified by 'sales';

grant select on manufacturer to salesperson;
grant select on car to salesperson;
grant select on customer to salesperson;
grant select on viewings to salesperson;

grant update(cost) on car to salesperson;

show grants for management;
show grants for salesperson;

SELECT user, host FROM mysql.user;
