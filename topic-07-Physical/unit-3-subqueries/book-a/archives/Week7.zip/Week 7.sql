use library;

#Page 2 Exercise
SELECT count(loanid) as 'Number of loans' 
FROM loan 
WHERE studentid = 
  (SELECT studentid 
   FROM student 
   WHERE studentid ='20038967');

#Page 3 Exercises
select title, price from book 
where price = (select min(price) from book);

select title, price from book 
where price > (select avg(price) from book);

select title, price - (select round((avg(price)),0) from book) as 'Price Difference' from book 
where price > (select avg(price) from book);

#Page 4 Exercises
select concat(fname, ' ', lname) as Name from author 
where authorid in (select authorid from authorship) order by lname, fname;

select concat(fname, ' ', lname) as Name from author 
where authorid not in (select authorid from authorship) order by lname, fname;

#Page 7 Exercise
use movies;

create or replace view filmreviewdetails as
select title, releaseYear, name, stars
from film join rating
on film.fid = rating.fid
join reviewer
on reviewer.rid = rating.rid;

select * from filmreviewdetails;

#Page 10 Exercises
create or replace view modernfilms as
select fId, title, releaseYear, director
from film
where releaseYear>1980
with check option;

select * from modernfilms;

insert into modernfilms values (111, 'The Kings Speech', 2010, 'Tom Hooper');
insert into modernfilms values (110, 'Lawrence of Arabia', 1962, 'David Lean');

