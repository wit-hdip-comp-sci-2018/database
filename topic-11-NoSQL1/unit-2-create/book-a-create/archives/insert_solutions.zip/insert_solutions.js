// Step Three, Exercise One

db.grades.insert( 
	{  
	  "student_id" : 50, 
	  "class_id" : 28, 
	  "scores" : [ 
		{ "type" : "exam", "score" : 58.6 }, 
		{ "type" : "quiz", "score" : 22.4 }, 
		{ "type" : "homework", "score" : 74.2 }, 
		{ "type" : "homework", "score" : 68.3 }, 
		{ "type" : "homework", "score" : 17.9 } 
	  ] 
	}
)


// Step Three, Exercise Two

db.grades.insert( 
    [{  
	  "student_id" : 50, 
	  "class_id" : 10, 
	  "scores" : [ 
		{ "type" : "exam", "score" : 68.5 }, 
		{ "type" : "quiz", "score" : 24.7 }, 
		{ "type" : "homework", "score" : 78.8 }, 
		{ "type" : "homework", "score" : 69.5 }, 
		{ "type" : "homework", "score" : 16.5 } 
	  ] 
	},
    {  
	  "student_id" : 50, 
	  "class_id" : 11, 
	  "scores" : [ 
		{ "type" : "exam", "score" : 52.1 }, 
		{ "type" : "quiz", "score" : 19.8 }, 
		{ "type" : "homework", "score" : 55.3 }, 
		{ "type" : "homework", "score" : 89.4 }, 
		{ "type" : "homework", "score" : 18.7 } 
	  ] 
	}]
)


// Step Four, Exercise One

db.grades.insertOne( 
	{  
      _id: 10, 
	  "student_id" : 50, 
	  "class_id" : 23, 
	  "scores" : [ 
		{ "type" : "exam", "score" : 54.1 }, 
		{ "type" : "quiz", "score" : 24.2 }, 
		{ "type" : "homework", "score" : 65.8 }, 
		{ "type" : "homework", "score" : 67.5 }, 
		{ "type" : "homework", "score" : 18.1 } 
	  ] 
	}
)


// Step Four, Exercise Two

try{
db.grades.insertOne(
    {
      _id: 10, 
      "student_id" : 50, 
      "class_id" : 23, 
      "scores" : [ 
        { "type" : "exam", "score" : 54.1 }, 
        { "type" : "quiz", "score" : 24.2 }, 
        { "type" : "homework", "score" : 65.8 }, 
        { "type" : "homework", "score" : 67.5 }, 
        { "type" : "homework", "score" : 18.1 } 
      ] 
    }
);  
} catch(e){
    print(e);
}


// Step Five, Exercise One

try{
db.grades.insertMany(
    [{
      "student_id" : 50, 
      "class_id" : 2, 
      "scores" : [ 
        { "type" : "exam", "score" : 58.6 }, 
        { "type" : "quiz", "score" : 18.9 }, 
        { "type" : "homework", "score" : 58.7 }, 
        { "type" : "homework", "score" : 68.7 }, 
        { "type" : "homework", "score" : 17.8 } 
      ] 
    },
    {
      "student_id" : 50, 
      "class_id" : 15, 
      "scores" : [ 
        { "type" : "exam", "score" : 55.4 }, 
        { "type" : "quiz", "score" : 18.7 }, 
        { "type" : "homework", "score" : 59.5 }, 
        { "type" : "homework", "score" : 82.1 }, 
        { "type" : "homework", "score" : 16.8 } 
      ] 
    }]
);  
} catch(e){
    print(e);
}
