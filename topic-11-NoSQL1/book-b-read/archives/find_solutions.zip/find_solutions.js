// Read(Find) Q1 

db.grades.find(
  {class_id: 0,student_id:4}
).pretty()


// Read(Find) Q2

db.grades.find(
  {$or: [
    {class_id: 23},
    {student_id:2}
  ]}
).pretty()


// Read(Find) Q3 

db.grades.find(
   {
      student_id: 28, 
	  class_id: { $in: [ 23, 29 ] }
   }
).pretty()


// Read(Find) Q4 

db.grades.find(
   {
      student_id: 40, 
	  class_id: { $nin: [ 1,2,14,22 ] }
   }
).pretty()


// Read(Find) Q5

db.grades.find( { student_id: {$eq: 5 } } ).pretty()


// Read(Find) Q6

db.grades.find(
   {
      class_id: 18, 
	  student_id: { $ne: 30 }
   }
).pretty()


// Read(Find) Q7

db.grades.find(
  {
    scores: {
      $elemMatch: {
        score: { $gt: 99, $lt: 100 }
      }
    }
  }
).pretty()


// Read(Find) Q8

db.grades.find(
  {
    scores: {
      $elemMatch: {
		  type: "quiz",
          score: { $gt: 35, $lt: 40 }
      }
    }
  }
).pretty()