use library;

#Page 1 Exercises
SELECT DATE_FORMAT('2018-12-25','%M %D, %Y') as 'Christmas Day';
SELECT DATE_FORMAT('2018-12-25','%a %D %M %Y') as 'Christmas Day';
SELECT DATE_FORMAT('2018-12-25','%W %D %M %Y') as 'Christmas Day';
SELECT DATE_FORMAT('2018-12-25','%e %b %Y') as 'Christmas Day';
SELECT DATE_FORMAT('2018-12-25','%e %M %y') as 'Christmas Day';

#Exercise - Insert
#1
insert into book 
values('133312345', 'Learning SQL', 'O Reilly', '2009-05-08', 'Computing', 25.00);

#2
insert into bookcopy(ISBN, dateAcquired)
values
('133312345', '2018-09-01'),
('133312345', '2018-09-01'),
('133312345', '2018-09-01');

#3
insert into Author(fName, lName)
values ('Adam', 'Beauleau');

select * from author;

#4
insert into authorship(authorId, ISBN)
values(14, '133312345');

#5
commit;

#Exercise - Update
#1
update book
set price = 28.00
where ISBN = '133312345';

#2
update bookcopy
set dateAcquired = '2018-09-12'
where ISBN = '133312345';

#3
commit;

#Exercise - Delete
#1
delete from bookcopy
where copyId = 63;

#2
commit;


