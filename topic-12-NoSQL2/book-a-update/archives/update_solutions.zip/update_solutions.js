// Update Q1 

db.grades.update(
   { student_id: 42 , class_id: 18 },
   { $set: { class_id: 19 } }
)


// Update Q2 

db.grades.update(
   { student_id: 38 , class_id: 23 },
   {
     $set: {
       "scores.2": {type: "homework", score: 60}
     }
   }
)


// Update Q3

db.grades.update(
  { student_id: 50, class_id: 2 },
  {
    $set: {
	  student_id: 50,
	  class_id: 2,
	  "scores" : [
	    { "type" : "exam", "score" : 57.9 },
	    { "type" : "quiz", "score" : 21.2 },
	    { "type" : "homework", "score" : 68.1 }
	  ]
	}
  },
  { upsert: true }
)


// Update Q4 

db.grades.update(
  { },
  { $set: { "scores.$[elem].score" : 100 } },
  {
    multi: true,
    arrayFilters: [ { "elem.score": { $gte: 99 } } ]
   }
)

db.grades.find(
  {
    scores: {
      $elemMatch: {
        score: { $eq: 100 }
      }
    }
  }
).pretty()


