// Delete Q1 

db.grades.remove( {student_id: 9, class_id: 15} )


// Delete Q2 

db.grades.remove( {student_id: 19} )


// Delete Q3

db.grades.find(
  {
    scores: {
      $elemMatch: {
		  type: "exam",
          score: { $lte: 5 }
      }
    }
  }
).pretty()

db.grades.remove(
  {
    scores: {
      $elemMatch: {
		  type: "exam",
          score: { $lte: 5 }
      }
    }
  }, true
)

