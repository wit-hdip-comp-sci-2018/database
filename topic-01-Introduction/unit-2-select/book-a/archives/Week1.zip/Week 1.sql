use library;

#Page 3 Exercise
desc book;
desc bookcopy;
desc student;
desc loan;
desc author;
desc authorship;

#Page 5 Exercises
select fName, lName, street, town, county from student;
select fName, lName,  county from student where county <> 'Waterford';
select * from student where year = 1;

#Page 6 Exercises
select title as 'Computing Titles' from book where category = 'Computing';
select distinct county as 'Student County' from student;
select studentid, concat(fName, ' ', lName) as 'Student Name' from student where course ='wd155';
select concat(fName, ' ', lName) as Name, street  from student where town ='Tramore';
select title as 'Sitepoint books'  from book where publisher = 'Sitepoint';

#Page 7 Exercises
select title, publisher from book where title like 'Database%';
select title, publisher from book where title like '%Engineering%';
select concat(fName, ' ', lName) as Name from student where lname like 'D%';

#Page 8 Exercise
select * from book where publisheddate between '2008-01-01' and '2013-12-31'; 

#Page 9 Exercise
select concat(fName, ' ', lName) as Name, town, county from student where county  in ('Kilkenny', 'Waterford', 'Wexford');

#Page 10 Exercises
select concat(fName, ' ', lName) as Name from student where county  = 'Waterford' and year = 1;
select title, price from book where  title like '%Database%' and price <=50;

#Page 12 Exercises
select concat(fName, ' ', lName) as Name from student where lName  = 'Ryan' order by fname;
select concat(fName, ' ', lName) as Name, town, county from student where county  in ('Kilkenny', 'Waterford', 'Wexford')
order by county, town;
select price, title from book where category = 'Business' order by price desc, title;
