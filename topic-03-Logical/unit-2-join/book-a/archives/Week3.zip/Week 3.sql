use library;

#Page 5 Exercises
select  title, copyid, publisher, dateacquired from book join bookcopy on book.isbn = bookcopy.isbn 
where dateacquired> '2014-06-01' order by title;

select  distinct concat(fName, ' ', lName) as Name from loan join student 
on loan.studentid = student.studentid;

select  distinct concat(fName, ' ', lName) as Name from loan join student 
on loan.studentid = student.studentid where dateback is null;

select concat(fName, ' ', lName) as Name, copyid, dateOut, dateback
from loan join student 
on loan.studentid = student.studentid
order by lname, fname;

select copyid, title from book join bookcopy on book.isbn = bookcopy.isbn where datedestroyed is null;

#Page 7 Exercises
select title, count(*) as 'Number of Books' from book join bookcopy on 
book.isbn=bookcopy.isbn
where title like '%database%'
group by title;

select concat(fName, ' ', lName) as Name, count(*) as 'Number of Loans'
from loan join student 
on loan.studentid = student.studentid 
group by Name
order by lName, fName;

select concat(fName, ' ', lName) as Name, count(*) as 'Number of Loans'
from loan join student 
on loan.studentid = student.studentid where dateback is null
group by Name
order by lName, fName;

#Movies Exercise
use movies;

select rid, title, director, stars from film join rating 
on film.fid = rating.fid
order by rid;

select count(*) as 'Number of Reviews left by Chris Jackson' from rating join reviewer on rating.rid = reviewer.rid where name = 'Chris Jackson';

select name, count(*) as 'Number of Reviews' from rating join reviewer on rating.rid = reviewer.rid group by name;

select title, count(*) as 'Number of Film Reviews' from film join rating 
on film.fid = rating.fid
group by title;